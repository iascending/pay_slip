import pdb, csv
from datetime import datetime

from PaySlip import PaySlip
from CsvFile import CsvFile

if __name__ == "__main__":

    fieldnames = ['Name', 'Pay Period', 'Gross Income', 'Income Tax', 'Net Income', 'Super']

    print("\nStarting to read input CSV file ..........")
    pay_slip_list = CsvFile('input.csv').read()

    for item in pay_slip_list: print("    {}".format(item))
    print("Completed input CSV file reading..........")

    # pdb.set_trace()
    print("\nWriting following PaySlips into output CSV file ..........")
    pay_slip_info = CsvFile('output.csv', fieldnames).write(pay_slip_list)

    for item in pay_slip_info: print("    {}".format(item))
    print("Completed output CSV file writing..........\n")
