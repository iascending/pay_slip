import csv
from datetime import datetime

from PaySlip import PaySlip

class CsvFile:
    """
    This is an class for reading and writing .csv file operations.
    attributes:
        file_name:      file_name to be opened for csv file read or write.
        fieldnames:     column names to be writen into output csv file.
        pay_slip_list:  a list of PaySlip objects created from input csv file.
        pay_slip_info:  a list of PaySlip details writen to output csv file.
    """
    def __init__(self, file_name, fieldnames=None):
        """The constructor of class. """
        self.file_name     = file_name
        self.fieldnames    = fieldnames
        self.pay_slip_list = []
        self.pay_slip_info = []

    def read(self):
        """
        Read employee basic payment info from a csv file,
        save into PaySlip object, and
        store as the element of pay_slip_list
        """
        with open(self.file_name, newline='') as file:
            reader = csv.reader(file)
            try:
                for row in reader:
                    if reader.line_num > 1:
                        first_name     = row[0]
                        last_name      = row[1]
                        annual_salary  = int(row[2])
                        super_rate     = float(row[3].strip('%'))/100
                        pay_start_date = datetime.strptime(row[4], "%d-%b-%y").date().strftime("%Y-%m-%d")
                        self.pay_slip_list.append(PaySlip(first_name, last_name, annual_salary, super_rate, pay_start_date))
                return self.pay_slip_list
            except csv.Error as e:
                sys.exit('file {}, line {}: {}'.format(self.file_name, reader.line_num, e))

    def write(self, pay_slip_list):
        """Write calculated employee detailed payment info into a csv file. """
        with open('output.csv', 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=self.fieldnames)
            writer.writeheader()

            for object in pay_slip_list:
                name         = object.first_name + " " + object.last_name
                pay_period   = object.get_pay_period()
                gross_income = object.get_gross_income()
                income_tax   = object.get_income_tax()
                net_income   = object.get_net_income()
                super        = object.get_monthly_super()
                writer.writerow({
                    self.fieldnames[0]: name,
                    self.fieldnames[1]: pay_period,
                    self.fieldnames[2]: gross_income,
                    self.fieldnames[3]: income_tax,
                    self.fieldnames[4]: net_income,
                    self.fieldnames[5]: super
                })
                self.pay_slip_info.append(
                    [name, pay_period, gross_income, income_tax, net_income, super]
                )

            return self.pay_slip_info
